package com.au.sessionmvc.controller.exception;

public class StudentNotFound extends Exception {

	

	public StudentNotFound(int id) {
		// TODO Auto-generated constructor stub
	}

}
