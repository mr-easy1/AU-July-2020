import React, { Component } from "react";

export default class Input extends Component {
  render() {
    const { item, handleChange, handleSubmit, editItem } = this.props;
    return (
      <div className="card card-body my-3">
        <form onSubmit={handleSubmit}>

            <input
              type="text"
              className="form-control text-capitalize"
             
              value={item}
              onChange={handleChange}
            />
        
          <button
            type="submit"
            className={
              editItem
                ? "btn btn-info mt-3"
                : "btn btn-info mt-3"
            }
          >
            {editItem ? "edit todo" : "add todo"}
          </button>
        </form>
      </div>
    );
  }
}
