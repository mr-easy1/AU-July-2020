
import java.io.File;
import java.util.Scanner;



public class Countfile {

    public static int[] getFileName(File f, String displacement)
    {
        System.out.println(displacement+"---D : "+f.getName());        
        displacement += "   |";
        File list[] = f.listFiles();
        int fileCount =0, DirectoryCount = 0;
        int RfileCount =0, RDirectoryCount = 0;
        
        
        for (File file : list) {
            if(file.isDirectory())
            {
                DirectoryCount++;
                RDirectoryCount++;
                
                int val[] = getFileName(file,displacement);
                RfileCount += val[0];
                RDirectoryCount += val[1];
            }else
            {
                fileCount++;
                RfileCount++;
                System.out.println(displacement +"---F : "+ file.getName());
            }
        }
        // printing total number of files and directory
        System.out.print(displacement+"(File : "+fileCount);
        System.out.println(" ,Directory : "+DirectoryCount+")");
        System.out.print(displacement+"(Total File : "+RfileCount);
        System.out.println(" ,Directory : "+RDirectoryCount+")");
        
        return new int[]{RfileCount,RDirectoryCount};
    }
    
    public static void main(String[] args) {
        
        // Take input 
        Scanner sc =  new Scanner(System.in);
        System.out.println("Enter the complete path for the desirable directory/files : ");
        String path = sc.nextLine();    
        File f = new File(path);     
        getFileName(f,"");
    }
    
}
