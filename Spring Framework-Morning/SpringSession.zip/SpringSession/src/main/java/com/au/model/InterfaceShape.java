package com.au.model;

public class InterfaceShape implements Shape {

	@Override
	public void getArea() {
		// TODO Auto-generated method stub
		
		
	}
	
	

}
