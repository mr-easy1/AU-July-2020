package com.au.model;

public interface Shape {
	public void getArea();

}
