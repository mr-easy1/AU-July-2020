package com.au.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.au.model.Circle;
import com.au.model.Point;
import com.au.model.Triangle;

public class SpringMain {
	
	
	public static void main(String args[])
	{	
//		Triangle t=new Triangle();
//		t.draw();
//		
//		AbstractApplicationContext context= new ClassPathXmlApplicationContext("spring.xml");
//		context.registerShutdownHook();
//		Triangle t= context.getBean(Triangle.class);
//		t.getType();
//		t.getPointA();
//		Circle cr= context.getBean(Circle.class);
////		cr.getType();
		
		   @SuppressWarnings("resource")
		   ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");

	        Triangle triangle = context.getBean(Triangle.class);
	        Circle circle = context.getBean(Circle.class);
	        triangle.draw();
	        circle.draw();
	        triangle.printPointMap();
	        System.out.println("Calculation for triangle");
	        triangle.getShape().getArea();
	        System.out.println();
	        System.out.println("Calculation for Circle");
	        circle.getShape().getArea();	
	}
}
