package com.au.model;

import com.au.model.Point;
import com.au.model.Shape;

public class Circle {
//	public String getType() {
//		System.out.println("Inside get type");
//		return null;
//	}
	
	private Shape shape;
    private String type;
    private Point center;
	public Shape getShape() {
		return shape;
	}
	public void setShape(Shape shape) {
		this.shape = shape;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Point getCenter() {
		return center;
	}
	public void setCenter(Point center) {
		this.center = center;
	}
    
	 public void draw(){
	        System.out.println("inside " + type);
	        System.out.println("Center: (" + center.getX() + ", " + center.getY() + ")");
	    }

}
