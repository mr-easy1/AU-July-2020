var express = require("express");
var app = express();
var fs = require("fs");
app.use(express.json());

//Listen function opens by default port on 3000 --here you change port no
app.listen(3000, () => {
    console.log("Server running on port 3000"); //check the console for the status
   });

// Add items into Todo List here...........
const lists=[
    {id: 1,value: "Todo item 1"},
    {id: 2,value: "Todo item 2"},
    {id: 3,value: "Todo item 3"},
    {id: 4,value: "Todo item 4"},
    {id: 5,value: "Todo item 5"},
    {id: 6,value: "Todo item 6"},
    {id: 7,value: "Todo item 7"},
    {id: 8, value: "Todo item 8"}
]

//hardcode Todoitem here
var newList={id: 9,value:"Todo item 9" };

//after hitting the local host URL
app.get('/', (req, res) => {
    res.send('Welcome for the testing of REST API\n\n ******************Info:Todo lists are hardcoded and there is no databse connectivity**********\n\n 1./Lists using GET method: to get all lists\n\n 2./List/addList- using POST method: to add a new List\n\n '+
    "3./Lists/id using GET method to get list with that id (1-8)\n"+"\n 4./Lists/id using PUT method: to edit a list and set new value to that list\n"+
    "\n 5./todoLists/id using DELETE method to delete the list with specified id")
    });


app.get('/Lists', function (req, res) {
     res.send(lists);
});


app.post('/Lists/addList', (req, res)=> {
    lists.push(newList);
    res.send(newList);
});


app.get('/Lists/:id', (req, res) => {
        const list = lists.find(c => c.id === parseInt(req.params.id));
        res.send(list);
});


app.put('/Lists/edit/:id', (req, res) => {
    const list = lists.find(c=> c.id === parseInt(req.params.id));
    list.value = req.body.value;
    res.send(list);
}); 


app.delete('/Lists/:id', (req, res) => {
    const list = lists.find( c=> c.id === parseInt(req.params.id));   
    const index = lists.indexOf(list);
    lists.splice(index,1);
    res.send(list);
});


     